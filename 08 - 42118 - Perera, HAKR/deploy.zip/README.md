# N Magazine - Campus News & Lifestyle Magazine

A web application developed for the NSBM Green University Web Development project.

Built using HTML5, CSS3, JavaScript, Bootstrap 5, Procedural PHP, and MySQL.

---

## Features

- **Campus News Feed:** Browse latest and trending campus news with category filters (Events, Academic, Clubs, Uni Life, Sports, General) and keyword search.
- **Role-Based Authentication:** Distinct user roles for Students and Administrators.
- **Article Submission & Review:** Students can submit stories for administrator review and track their review status.
- **Article Editing:** Authors and administrators can edit submitted and published articles.
- **Interactive Reading View:** Single article view with side category navigation, author information, view count tracking, and bookmarking.
- **Discussion & Comments:** Registered students and staff can post comments and engage in campus discussions.
- **Mindscape Community Wall:** Interactive campus thought wall where students can share short updates and reflections.
- **Admin Control Dashboard:** Consolidated management panel for news approvals, article editing, category creation, comment moderation, and user accounts.

---

## How to Run

### Localhost with XAMPP

1. **Start Apache & MySQL:** Open the XAMPP Control Panel and start Apache and MySQL.
2. **Open Setup Wizard:** In your browser, open:
   ```text
   http://localhost/webproject/setup.php
   ```
3. **Database Setup:** Click **"Install Database Now"** to create the tables and seed default sample data.
4. **Access the Application:** Open:
   ```text
   http://localhost/webproject/
   ```

---

## Default Login Credentials

| Role | Email | Password | Access |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@nsbm.ac.lk` | `admin123` | Full administrative control (Dashboard, Articles, Approvals, Categories, Comments, Users) |
| **Student** | `student@nsbm.ac.lk` | `student123` | Read news, submit articles, edit submissions, post comments, bookmark stories |
| **Student** | `amaya@nsbm.ac.lk` | `student123` | Read news, submit articles, edit submissions, post comments, bookmark stories |

---

## File Structure

```text
├── config.php             # Database and environment configuration
├── database.sql           # Database schema and initial data
├── db.php                 # MySQL connection and helper functions
├── setup.php              # Database installation wizard
├── index.php              # Homepage with news feed and category filtering
├── view_article.php       # Article reading view with sidebar category navigation
├── edit_article.php       # Article editor for authors and administrators
├── submit_article.php     # Article submission portal
├── bookmarks.php          # Saved bookmarks
├── my_submissions.php     # Student submission status tracker
├── mindscape.php          # Campus thought wall
├── profile.php            # User profile and settings
├── login.html / login.php # User authentication
├── register.html / register.php # Student registration
├── logout.php             # Session sign out
├── admin.php              # Admin control panel
├── includes/
│   ├── header.php         # Document head and stylesheets
│   ├── navbar.php         # Navigation bar
│   ├── footer.php         # Page footer
│   └── preloader.php      # Page preloader
└── assets/
    ├── css/style.css      # Custom styles and NSBM color palette
    └── js/main.js         # Frontend scripts
```
