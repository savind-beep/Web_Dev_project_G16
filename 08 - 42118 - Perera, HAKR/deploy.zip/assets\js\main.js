// ========================================================
// N Magazine - Simple Client-Side Helpers
// ========================================================

document.addEventListener("DOMContentLoaded", function () {
  // Confirmation for delete actions
  const deleteButtons = document.querySelectorAll(".confirm-delete");
  deleteButtons.forEach(function (button) {
    button.addEventListener("click", function (e) {
      const message = this.getAttribute("data-message") || "Are you sure you want to delete this item? This action cannot be undone.";
      if (!confirm(message)) {
        e.preventDefault();
      }
    });
  });

  // Auto-dismiss alert banners after 5 seconds if desired
  const alerts = document.querySelectorAll(".alert-auto-dismiss");
  alerts.forEach(function (alert) {
    setTimeout(function () {
      alert.style.transition = "opacity 0.5s ease";
      alert.style.opacity = "0";
      setTimeout(function () {
        alert.remove();
      }, 500);
    }, 5000);
  });

  // Floating Scroll-to-Top "Go Up" button
  const scrollBtn = document.getElementById("scrollToTopBtn");
  if (scrollBtn) {
    window.addEventListener("scroll", function () {
      if (window.scrollY > 200) {
        scrollBtn.classList.add("show");
      } else {
        scrollBtn.classList.remove("show");
      }
    });

    scrollBtn.addEventListener("click", function () {
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    });
  }

  // Ambient Campus Hero Video Background (Zero Controls, Seamless Infinite Loop)
  const heroVideo = document.getElementById("heroVideo") || document.querySelector(".hero-video-bg");
  if (heroVideo) {
    heroVideo.muted = true;
    heroVideo.defaultMuted = true;
    heroVideo.playsInline = true;

    const playHeroVideo = function () {
      const promise = heroVideo.play();
      if (promise !== undefined) {
        promise.catch(function () {
          const unlock = function () {
            heroVideo.muted = true;
            heroVideo.play().catch(function () {});
            ["click", "touchstart", "scroll", "keydown"].forEach(function (evt) {
              document.removeEventListener(evt, unlock);
            });
          };
          ["click", "touchstart", "scroll", "keydown"].forEach(function (evt) {
            document.addEventListener(evt, unlock, { once: true, passive: true });
          });
        });
      }
    };

    playHeroVideo();
    heroVideo.addEventListener("loadedmetadata", playHeroVideo);
    heroVideo.addEventListener("canplay", playHeroVideo);
    heroVideo.addEventListener("ended", function () {
      heroVideo.currentTime = 0;
      heroVideo.play().catch(function () {});
    });
  }
});

// Helper to replay minimalist preloader for testing if needed
window.replayPreloader = function () {
  var p = document.getElementById("sitePreloader");
  if (!p) return;
  p.classList.remove("fade-out");
  p.style.display = "flex";
  var fill = p.querySelector(".preloader-fill");
  if (fill) {
    fill.style.animation = "none";
    fill.offsetHeight; /* trigger reflow */
    fill.style.animation = "";
  }
  setTimeout(function () {
    p.classList.add("fade-out");
    setTimeout(function () { p.style.display = "none"; }, 400);
  }, 1300);
};

// ========================================================
// Theme Toggle Initializer (Desktop & Mobile)
// ========================================================
(function () {
  var html = document.documentElement;

  function getStoredTheme() {
    try {
      return localStorage.getItem('nsbm-theme') || 'light';
    } catch (e) {
      return 'light';
    }
  }

  function applyTheme(theme) {
    html.setAttribute('data-theme', theme);
    try { localStorage.setItem('nsbm-theme', theme); } catch (e) {}
    updateIcons(theme);
  }

  function updateIcons(theme) {
    var isDark = theme === 'dark';
    var icons = document.querySelectorAll('.dark-mode-icon, #darkModeIcon, #darkModeIconMobile, #darkModeIconDrawer');
    icons.forEach(function (icon) {
      if (isDark) {
        icon.className = 'bi bi-sun-fill dark-mode-icon';
        icon.style.color = '#00ff88';
      } else {
        icon.className = 'bi bi-moon-stars-fill dark-mode-icon';
        icon.style.color = '';
      }
    });
  }

  function attachThemeListeners() {
    var buttons = document.querySelectorAll('.dark-mode-toggle, #darkModeToggle, #darkModeToggleMobile, #darkModeToggleDrawer');
    buttons.forEach(function (btn) {
      if (btn.dataset.themeBound === 'true') return;
      btn.dataset.themeBound = 'true';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var current = html.getAttribute('data-theme') || 'light';
        var next = current === 'dark' ? 'light' : 'dark';
        applyTheme(next);
      });
    });
    updateIcons(html.getAttribute('data-theme') || getStoredTheme());
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachThemeListeners);
  } else {
    attachThemeListeners();
  }
})();



