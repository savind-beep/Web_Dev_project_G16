</main>

<!-- Floating Scroll-To-Top "Go Up" Button -->
<button id="scrollToTopBtn" class="btn-scroll-top" title="Go Up" aria-label="Scroll to top">
    <i class="bi bi-arrow-up-short"></i>
</button>

<!-- Thin Minimalist Footer -->
<footer class="nsbm-footer-thin">
    <div class="container">
        <div class="footer-thin-content">
            <!-- Brand & Copyright -->
            <div class="footer-thin-brand">
                <a href="index.php" class="d-inline-flex align-items-center">
                    <img src="assets/images/logo_nav.png" alt="N Magazine" height="22" class="footer-logo">
                </a>
                <span class="footer-divider">&bull;</span>
                <span class="footer-copy">&copy; <?php echo date("Y"); ?> NSBM NewsDesk &bull; Group 16</span>
            </div>

            <!-- Quick Links Inline -->
            <nav class="footer-thin-links" aria-label="Footer Navigation">
                <a href="index.php">Home</a>
                <a href="index.php?category=academic">Academic</a>
                <a href="index.php?category=events">Events</a>
                <a href="index.php?category=sports">Sports</a>
                <a href="mindscape.php">Mindscape</a>
                <a href="submit_article.php">Submit News</a>
            </nav>

            <!-- Social Links -->
            <div class="footer-thin-socials">
                <a href="https://www.facebook.com/nsbm.lk" target="_blank" rel="noopener noreferrer" title="Facebook"><i class="bi bi-facebook"></i></a>
                <a href="https://www.instagram.com/nsbmgreenuniversity/" target="_blank" rel="noopener noreferrer" title="Instagram"><i class="bi bi-instagram"></i></a>
                <a href="https://www.tiktok.com/@nsbmgreenuniversity" target="_blank" rel="noopener noreferrer" title="TikTok"><i class="bi bi-tiktok"></i></a>
                <a href="https://www.youtube.com/@NSBMGreenUniversityTown/" target="_blank" rel="noopener noreferrer" title="YouTube"><i class="bi bi-youtube"></i></a>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle (with Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JavaScript -->
<script src="assets/js/main.js"></script>
<!-- Dark Mode Toggle Script -->
<script>
(function () {
    const html = document.documentElement;

    function getStoredTheme() {
        try {
            return localStorage.getItem('nsbm-theme') || 'light';
        } catch (e) {
            return 'light';
        }
    }

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme);
        try { localStorage.setItem('nsbm-theme', theme); } catch (e) {}
        updateIcons(theme);
    }

    function updateIcons(theme) {
        const isDark = theme === 'dark';
        const icons = document.querySelectorAll('.dark-mode-icon, #darkModeIcon, #darkModeIconMobile, #darkModeIconDrawer');
        icons.forEach(function (icon) {
            if (isDark) {
                icon.className = 'bi bi-sun-fill dark-mode-icon';
                icon.style.color = '#00ff88';
            } else {
                icon.className = 'bi bi-moon-stars-fill dark-mode-icon';
                icon.style.color = '';
            }
        });
    }

    // Apply stored theme immediately
    applyTheme(getStoredTheme());

    function attachListeners() {
        const buttons = document.querySelectorAll('.dark-mode-toggle, #darkModeToggle, #darkModeToggleMobile, #darkModeToggleDrawer');
        buttons.forEach(function (btn) {
            if (btn.dataset.themeBound === 'true') return;
            btn.dataset.themeBound = 'true';
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                const current = html.getAttribute('data-theme') || 'light';
                const next = current === 'dark' ? 'light' : 'dark';
                applyTheme(next);
            });
        });
        updateIcons(html.getAttribute('data-theme') || 'light');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachListeners);
    } else {
        attachListeners();
    }

    // Cross-tab theme sync
    window.addEventListener('storage', function (e) {
        if (e.key === 'nsbm-theme' && e.newValue) {
            applyTheme(e.newValue);
        }
    });
})();
</script>
</body>
</html>
