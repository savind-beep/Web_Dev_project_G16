========================================================================
             N MAGAZINE - CAMPUS NEWS & LIFESTYLE MAGAZINE
========================================================================

NSBM Green University Web Development Project.
Technologies: HTML5, CSS3, JavaScript, Bootstrap 5, PHP, MySQL.

------------------------------------------------------------------------
1. DEFAULT LOGIN CREDENTIALS
------------------------------------------------------------------------

[ADMINISTRATOR]
- Email:    admin@nsbm.ac.lk
- Password: admin123
- Role:     Administrator

[STUDENT]
- Email:    student@nsbm.ac.lk
- Password: student123
- Role:     Student

[STUDENT 2]
- Email:    amaya@nsbm.ac.lk
- Password: student123
- Role:     Student

------------------------------------------------------------------------
2. HOW TO RUN ON LOCALHOST
------------------------------------------------------------------------

1. Open XAMPP Control Panel.
2. Start Apache and MySQL.
3. Open your browser and go to:
   http://localhost/webproject/setup.php
4. Click "Install Database Now".
5. Visit the main website:
   http://localhost/webproject/

------------------------------------------------------------------------
3. LIVE HOSTING SETUP
------------------------------------------------------------------------

1. Upload the project files to your server directory (e.g. htdocs or public_html).
2. Configure database credentials in config.php under production settings.
3. Visit https://yourdomain.com/setup.php and install the database.